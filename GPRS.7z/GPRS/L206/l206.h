/*
 * @file    l206.h
 *
 * @brief   L206模块控制接口
 *
 * @log     Date            Author          Notes
 *          2018-10-16      yue_jian        初始版本
 */

#ifndef L206_H
#define L206_H

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>

/* L206 工作状态 */
typedef enum
{
    L206_STA_STOP,
    L206_STA_STARTING,
    L206_STA_ATTACH,
    L206_STA_WAKE,
    L206_STA_SLEEP,
    L206_STA_STOPPING,
} L206State_t;

/**
 * @brief 初始化 
 */
void L206Init(void);

/**
 * @brief 开关机
 */
void L206Start(void);
void L206Stop(void);

/**
 * @brief 休眠唤醒
 */
void L206Wake(void);
void L206Sleep(void);

/**
 * @brief 获取L206当前工作状态
 */
L206State_t L206GetStatus(void);

/**
 * @brief 是否存在SIM卡
 */
bool L206HasSimCard(void);

/**
 * @brief 清楚保留的sim状态，尝试开机
 */
void L206ClrSimState(void);


/**
 * @brief 获取ICCID
 */
char *L206GetIccid(void);

/**
 * @brief 获取版本
 */
void L206GetVersion(void);

/**
 * @brief 设置APN
 */
void L206SetApn(char *apn);

/**
 * @brief 设置PSM
 */
void L206SetPsm(void);

/**
 * @brief 检测L206是否已入网
 */
void L206AttachCheck(void);

/**
 * @brief TCP通信接口
 */
bool L206TcpIsSetUp(void);
bool L206TcpIsSendComplete(void);
void L206TcpSetup(char *ip, char *port);
void L206TcpSend(char *buffer, size_t size);
void L206TcpClose(void);
size_t L206GetTcpData(uint8_t **buffer);

/**
 * @brief 处理从L206模块接收到的串口数据
 */
void L206ProcessUartData(uint8_t *buffer, size_t size);

#endif

