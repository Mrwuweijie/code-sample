/**
 * @file    ws_run.h
 *
 * @brief   维持websocket连接, 解析/发送websocket数据
 *
 * @auth    yue_jian
 * @date    2018-3-31 09:07:58
 * @sdk     simplelink_cc2640r2_sdk_01_50_00_58   
 */

#ifndef WS_RUN_H
#define WS_RUN_H

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>

#include "ws_client.h"

/* websocket 连接超时时间, 单位Ms */
#define WS_CONNECT_TIMEOUT          (10*1000)

/* tcp数据最大发送长度 */
#define TCP_SEND_MAX_LEN            (256)

/* 服务器信息 */
typedef struct {
    char *ip;
    char *port;
    char *path;
} ws_server_info_t;

/* websocet连接信息 */
typedef struct 
{
    /* 保存ws当前轮询状态 */
    ws_status_e cur_status;

    /* 最后一次发起连接时刻 */
    uint32_t last_connect_tick; 

    /* tcp数据发送缓冲区, 10字节为ws帧头预留 */
    char tcp_sendbuf[TCP_SEND_MAX_LEN + 10];
} ws_object_t;

/* 保存上层收发处理函数 */
typedef struct {
    /* 此函数中进行websocket数据发送 */
    void (*ws_send_callback)(ws_object_t *obj);

    /* 此函数中处理websocket接收数据 */
    void (*ws_recv_callback)(ws_frame_t *pFrame);

    /* 通知上层websocket建立连接 */
    void (*ws_connect)(void);
} ws_cbs_t;

/**@brief 注册上层回调函数
 */
void ws_register_callback(ws_cbs_t *cbs);

/**@brief 设置服务器信息
 */
void ws_set_server_info(ws_server_info_t *info);

/**@brief 处理tcp数据 
 */
void ws_process_tcpdata(char *buf, size_t buflen);

/**@brief 轮询调用, 维护连接状态
 */
void ws_run(void);

#endif

