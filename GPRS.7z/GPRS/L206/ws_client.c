/**
 * @file    ws_client.h
 *
 * @brief   websocket客户端接口
 *
 * @auth    yue_jian
 * @date    2018-3-30 13:13:52
 * @sdk     simplelink_cc2640r2_sdk_01_50_00_58   
 */

#include "ws_client.h"

#include <string.h>
#include <stdint.h>
#include "l206-board.h"

#include "l206.h"

// sec-websocket-key  src:gilfoylehandsome
static const char *_ws_key = "Z2lsZm95bGVoYW5kc29tZQ==";
// mask key
static const char _mask_key[4] = {0x37, 0xfa, 0x21, 0x3d};

static ws_status_e websocketState = WS_CLOSED;

void ws_init(void)
{
    websocketState = WS_CLOSED;
}

//获取当前的连接状态
ws_status_e ws_get_status(void)
{
    return websocketState;
}

bool ws_connect(char const *ip, char const *port)
{
    websocketState = WS_CONNECTING;
    L206TcpSetup(ip, port);
    return L206TcpIsSetUp();
}

//关闭WebSocket连接
void ws_close(void)
{
    if (websocketState != WS_CLOSED) {
        L206TcpClose();
        websocketState = WS_CLOSED;
    }
}

void ws_ping(void)
{
    char buf[10] = {0};
    ws_send_data_frame(buf, sizeof(buf), 0, WS_FRAME_PING);
}

void ws_send_handshake(char *buf, const char *ip, const char *port, const char *path)
{
    if (buf == NULL) {
        return;
    }

    int offset = 0;

    // first line
    {
        strcpy(buf+offset, "GET ");
        offset = strlen(buf);
        strcpy(buf+offset, path);
        offset = strlen(buf);
        strcpy(buf+offset, " HTTP/1.1\r\n");
        offset = strlen(buf);
    }

    // HOST
    {
        strcpy(buf+offset, "HOST: ");
        offset = strlen(buf);

        strcpy(buf+offset, ip);
        offset = strlen(buf);

        buf[offset++] = ':';

        strcpy(buf+offset, port);
        offset = strlen(buf);

        strcpy(buf+offset, "\r\n");
        offset = strlen(buf);
    }

    // Connection
    {
        strcpy(buf+offset, "Connection: Upgrade\r\n");
        offset = strlen(buf);
    }

    // Upgrade
    {
        strcpy(buf+offset, "Upgrade: websocket\r\n");
        offset = strlen(buf);
    }

    // Origin
    {
        strcpy(buf+offset, "Origin: null\r\n");
        offset = strlen(buf);
    }

    // Sec-WebSocket-Version
    {
        strcpy(buf+offset, "Sec-WebSocket-Version: 13\r\n");
        offset = strlen(buf);
    }

    // Sec-WebSocket-Key
    {
        strcpy(buf+offset, "Sec-WebSocket-Key: ");
        offset = strlen(buf);
        strcpy(buf+offset, _ws_key);
        offset = strlen(buf);
    }

    {
        strcpy(buf+offset, "\r\n\r\n");
        offset = strlen(buf);
    }

    L206TcpSend(buf, strlen(buf));

    bool ret = L206TcpIsSendComplete();
    if (true == ret) {
        websocketState = WS_HANDSHAKING;
    }
    else {
        L206UartWriteString("::handshake send fail\r\n");
        ws_close();
    }
}

ws_rspcode_e ws_process_handshake_response(char *buf, size_t buflen)
{
    ws_rspcode_e response = WS_RES_UNKNOWN;

    if (buf == NULL) {
        return WS_RES_UNKNOWN;
    }

    if (strstr(buf, "101")) {
        websocketState = WS_CONNECTED;
        response = WS_RES_101;
    }
    else if (strstr(buf, "403")) {
        response = WS_RES_403;
    }
    else if (strstr(buf, "405")) {
        response = WS_RES_405;
    }
    else if (strstr(buf, "426")) {
        response = WS_RES_426;
    }
    else {
        response = WS_RES_UNKNOWN;
    }

    return response;
}

void ws_send_data_frame(char *buf, size_t buflen, size_t payloadlen, ws_opcode_e code)
{
    if (buf == NULL) {
        return;
    }

    unsigned int head_len = 0, offset = 0;

    // 计算头所需空间
    head_len = (payloadlen<0x7e) ? 6 : 8;

    if (buflen < payloadlen + head_len) {
        return;
    }

    memmove(buf+head_len, buf, payloadlen);
    memset(buf, 0, head_len);

    buf[offset++] = 0x80 | code;
    if (head_len == 6) {
        buf[offset++] = 0x80 | payloadlen;
    }
    else if (head_len == 8) {
        buf[offset++] = 0x80 | 0x7e;
        buf[offset++] = (payloadlen>>8) & 0xff;
        buf[offset++] = payloadlen & 0xff;
    }

    buf[offset++] = _mask_key[0]; 
    buf[offset++] = _mask_key[1];
    buf[offset++] = _mask_key[2];
    buf[offset++] = _mask_key[3];

    // 根据掩码加密payload数据
    for(int i=0; i<payloadlen; i++) {
        buf[offset] = buf[offset] ^ (_mask_key[i%4]);
        offset++;
    }

    L206TcpSend(buf, offset);

    bool ret = L206TcpIsSendComplete();

    if (false == ret) {
        L206UartWriteString("::ws data send fail\r\n");
        ws_close();
    }
}

bool ws_parse_recv_frame(char *buf, size_t buflen, ws_frame_t *wsframe)
{
    if (buf == NULL || wsframe == NULL) {
        return false;
    }

    size_t payload_len = 0, head_len = 0;
    char mask_flag = 0;
    char mask[4] = {0};

    if (buflen < 2) {
        // ws数据包最少2个字节  		
        return false;
    }

    // 第一个字节 	
    {
        if ((buf[0] & 0x80) != 0x80) {
            // 不处理分匿	  		
            return false;
        }

        wsframe->opcode = buf[0] & 0x0f;
        head_len++;
    }

    // 第二个字芿	
    {
        mask_flag = (buf[1]&0x80) == 0x80;
        payload_len = buf[1] & 0x7f;

        head_len++;
    }

    // 根据前两个字节计算帧头和payload长度
    {
        if (payload_len < 0x7e) {
            payload_len = payload_len;
        }
        else if (payload_len == 0x7e) {	  		
            payload_len = (buf[2] & 0xff) << 8 | (buf[3] & 0xff);
            head_len += 2;
        }
        else {
            return false;
        }

        if (mask_flag) {
            head_len += 4;
        }
    }

    if (buflen < (head_len + payload_len)) {
        // 长度不对
        return false;
    }

    if (payload_len > 0) {
        wsframe->payload = buf + head_len;
    }
    else {
        wsframe->payload = NULL;
    }

    wsframe->payloadLen = payload_len;

    // 如果使用掩码，解析数捿	
    if (mask_flag) {
        if (payload_len < 0x7e) {
            memcpy(mask, buf+2, 4);
        }
        else {
            memcpy(mask, buf+4, 4);
        }

        for (int i=0; i<payload_len; i++) {
            wsframe->payload[i] = wsframe->payload[i] ^ mask[i%4];
        }
    }

    return true;
}

