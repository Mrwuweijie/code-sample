/**
 * @file    ws_run.c
 *
 * @brief   维持websocket连接, 处理websocket数据
 *
 * @auth    yue_jian
 * @date    2018-3-31 09:07:58
 * @sdk     simplelink_cc2640r2_sdk_01_50_00_58   
 */

#include "ws_run.h"

#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "L206.h"
#include "system/systime.h"
#include "l206-board.h"

static ws_object_t ws_obj;

static ws_cbs_t *ws_cbs;

static ws_server_info_t *server_info;

void ws_process_tcpdata(char *buf, size_t buflen)
{
    ws_status_e ws_state = ws_get_status();

    if (ws_state == WS_HANDSHAKING) 
    {
        if (WS_RES_101 != ws_process_handshake_response(buf, buflen)) 
        {
            L206UartWriteString("::handshake rsp error\r\n");
            ws_close();
        }
        else
        {
            if (ws_cbs->ws_connect) ws_cbs->ws_connect();
        }
    }
    else if (ws_state == WS_CONNECTED) {
        ws_frame_t frame;

        bool ret = ws_parse_recv_frame(buf, buflen, &frame);

        if (ret == false) {
            return;
        }

        if (ws_cbs != NULL && ws_cbs->ws_recv_callback != NULL) {
            ws_cbs->ws_recv_callback(&frame);
        }
    }
}

void ws_run(void)
{
    uint32_t curTick = SysTimeGetMcuTimeMs();
    ws_obj.cur_status = ws_get_status();

    switch(ws_obj.cur_status)
    {
        case WS_CLOSED:
            /* 连接失败, WS_CONNECT_TIMEOUT 时间后重新连接 */
            if (curTick - ws_obj.last_connect_tick > WS_CONNECT_TIMEOUT) {

                if (server_info != NULL) {
                    char *ip = server_info->ip;
                    char *port = server_info->port;
                    char *path = server_info->path;

                    if (ws_connect(ip, port) == true) {
                        memset(ws_obj.tcp_sendbuf, 0, TCP_SEND_MAX_LEN);
                        ws_send_handshake(ws_obj.tcp_sendbuf, ip, port, path);
                        ws_obj.last_connect_tick = curTick;
                    }
                    else {
                        L206UartWriteString("::ws connect fail\r\n");
                        ws_close();
                    }
                }
            }
            break;

        case WS_HANDSHAKING:
            /* 和WS_CONNECTING处理相同, no break */
        case WS_CONNECTING:
            /* 连接超时, 断开重连 */
            if (curTick - ws_obj.last_connect_tick > WS_CONNECT_TIMEOUT) {
                L206UartWriteString("::handshake timeout\r\n");
                ws_close();
            }
            break;

        case WS_CONNECTED:
            if (ws_cbs != NULL && ws_cbs->ws_send_callback != NULL) {
                ws_cbs->ws_send_callback(&ws_obj);
            }
            break;

        default:
            break;
    }
}

void ws_register_callback(ws_cbs_t *cbs)
{
    ws_cbs = cbs; 
}

void ws_set_server_info(ws_server_info_t *info)
{
    server_info = info;
}

