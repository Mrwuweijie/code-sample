/*
 * @file    l206.c
 *
 * @brief   L206模块控制接口
 *
 * @log     Date            Author          Notes
 *          2018-10-16      yue_jian        初始版本
 */
#include "l206.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "utilities.h"
#include "board.h"
#include "l206-board.h"
#include "system/delay.h"
#include "system/systime.h"
#include "system/timer.h"
#include "ws_run.h"


/* 设置AT指令缓冲区长度 */
#define L206_AT_MAX_LEN                 128

/* 设置udp单次接收数据包最大长度 */
#define L206_TCP_RECV_MAX_LEN           300

/* L206开机时间 */
#define L206_POWER_ON_TIME              3*1000

/* L206关机时间 */
#define L206_POWER_OFF_TIME             10*1000

/* L206AT命令发送缓存 */
static uint8_t L206AtSendBuffer[L206_AT_MAX_LEN];

/* L206AT命令接收缓存 */
static uint8_t L206AtRecvBuffer[L206_AT_MAX_LEN];

/* L206TCP数据缓存 */
static uint8_t L206TcpRecvBuffer[L206_TCP_RECV_MAX_LEN];

/* 已缓存的TCP数据长度 */
static size_t L206TcpRecvBufferLen = 0;

/* L206接收到的TCP数据包长度 */
static size_t L206TcpPkgLen = 0;

/* 保存sim卡20字节ICCID */
static char L206Iccid[21];

/* 保存当前工作状态 */
static L206State_t L206State = L206_STA_STOP;

/* TCP状态同步 */
static bool TcpSetupOkey = false;
static bool TcpSendReady = false;
static bool TcpSendComplete = false;

/* sim卡存在标志 */
static bool SimCardIsExist = true;

/* 开关机定时器 */
static TimerEvent_t L206PowerTimer;

static void OnL206PowerOn(void)
{
    L206PwrPullUp();
    L206State = L206_STA_ATTACH;
}

static void OnL206PowerOff(void)
{
    L206PwrPullUp();
    L206State = L206_STA_STOP;
}

void L206Init(void)
{
    L206State = L206_STA_STOP;
}

void L206Start(void)
{
    /* 开启串口接收 */
    L206UartEnable();

    /* pwr key 拉低3s开机 */
    L206PwrPullDown();
    L206State = L206_STA_STARTING;

    TimerInit(&L206PowerTimer, OnL206PowerOn);
    TimerSetValue(&L206PowerTimer, L206_POWER_ON_TIME);
    TimerStart(&L206PowerTimer);
}

void L206Stop(void)
{
    /* 关闭串口接收 */
    L206UartDisable();

    /* pwr key 拉低10s关机 */
    L206PwrPullDown();
    L206State = L206_STA_STOPPING;

    TimerInit(&L206PowerTimer, OnL206PowerOff);
    TimerSetValue(&L206PowerTimer, L206_POWER_OFF_TIME);
    TimerStart(&L206PowerTimer);
}

void L206Wake(void)
{
    L206UartEnable();
//    L206ExitPsm();
    L206State = L206_STA_ATTACH;
}

void L206Sleep(void)
{
    L206UartDisable();
    L206State = L206_STA_SLEEP;
}

L206State_t L206GetStatus(void)
{
    return L206State;
}

bool L206HasSimCard(void)
{
    return SimCardIsExist;
}

void L206ClrSimState(void)
{
    SimCardIsExist = true;
}

void L206GetVersion(void)
{
    L206UartWriteString("ATI\r\n");
    DelayMs(100);
}

void L206SetApn(char *apn)
{
    int length = snprintf((char *)L206AtSendBuffer, L206_AT_MAX_LEN,
                          "AT+CSTT=\"%s\"\r\n", apn);
    assert_debug(length > 0);

    L206UartWrite(L206AtSendBuffer, length);
    DelayMs(100);
}

void L206SetPsm(void)
{
//    L206UartWriteString("AT+CPSMS=1,,,\"10101010\",\"00000101\"\r\n");
//    DelayMs(100);
}

void L206AttachCheck(void)
{
//    L206ExitPsm();
    L206UartWriteString("AT+CGATT?\r\n");
    DelayMs(300);
}

char *L206GetIccid(void)
{
    if (L206Iccid[0] == 0)
    {
        L206UartWriteString("AT+ICCID\r\n");
        DelayMs(200);
    }

    return L206Iccid;
}

static void TcpTimeout(void)
{
    L206State = L206_STA_ATTACH;
    TcpSetupOkey = false;
}

bool L206TcpIsSetUp(void)
{
    return TcpSetupOkey;
}

bool L206TcpIsSendComplete(void)
{
    return TcpSendComplete;
}


void L206TcpSetup(char *ip, char *port)
{
    int length = 0;
    uint32_t delayCycle = 0;
    
    L206SetApn("CMNET");
    /* 关闭TCP TCP连接复用 */
    L206UartWriteString("AT+CIPMUX=0\r\n");
    DelayMs(100);

    L206UartWriteString("AT+CIPSHUT\r\n");
    DelayMs(100);

    length = snprintf((char *)L206AtSendBuffer, L206_AT_MAX_LEN,
                          "AT+CIPSTART=\"TCP\",\"%s\",\"%s\"\r\n", ip, port);
    assert_debug(length > 0);

    L206UartWrite(L206AtSendBuffer, length);

    /* 对于TCP通信, 这里同步等待CONNECT OK */
    delayCycle = 0;
    TcpSetupOkey = false;

    BoardReloadWD();

    while (1)
    {
        DelayMs(1);

        if (++delayCycle > 5000)
        {
            TcpTimeout();
            return;
        }

        if (TcpSetupOkey)
        {
            break;
        }
    }
    BoardReloadWD();
}

void L206TcpSend(char *buffer, size_t size)
{
    int length;
    uint32_t delayCycle = 0;

    length = snprintf((char *)L206AtSendBuffer, L206_AT_MAX_LEN, 
                          "AT+CIPSEND=%u\r\n", size);
    assert_debug(length > 0);

    L206UartWrite(L206AtSendBuffer, length);

    /* 同步等待TCP发送就绪 */
    delayCycle = 0;
    TcpSendReady = false;

    BoardReloadWD();

    while (1)
    {
        DelayMs(1);

        if (++delayCycle > 1000)
        {
            /* 超时也发送数据,防止没收到串口回应导致这里卡住 */
            L206UartWrite(L206AtSendBuffer, length);
            TcpTimeout();
            return;
        }

        if (TcpSendReady)
        {
            break;
        }
    }

    /* 发送TCP数据 */
    L206UartWrite((uint8_t *)buffer, size);

    /* 同步等待TCP发送完成 */
    delayCycle = 0;
    TcpSendComplete = false;

    BoardReloadWD();

    while (1)
    {
        DelayMs(1);

        if (++delayCycle > 1000)
        {
            /* 超时也发送数据,防止没收到串口回应导致这里卡住 */
            L206UartWrite(L206AtSendBuffer, length);
            TcpTimeout();
            return;
        }

        if (TcpSendComplete)
        {
            break;
        }
    }
}

void L206TcpClose(void)
{
    L206UartWriteString("AT+CIPCLOSE\r\n");
    DelayMs(100);

    TcpSetupOkey = false;
}

size_t L206GetTcpData(uint8_t **buffer)
{
    size_t udpLen = 0;

    if (L206TcpRecvBufferLen > 0)
    {
        *buffer = L206TcpRecvBuffer;
        udpLen = L206TcpRecvBufferLen;
        L206TcpRecvBufferLen = 0;
    }

    return udpLen;
}

/* 串口空闲中断时调用处理数据, 不可使用断言 */
static void L206ProcessAtCmd(char *cmd)
{
    if (memcmp(cmd, "+RECEIVE", 8) == 0)
    {
        char *pos1 = strchr(cmd, ',');
        char *pos2 = NULL;
        if (pos1)
            pos2 = strchr(pos1+1, ',');
        
        if((NULL == pos1) || (NULL == pos2)) 
        {
            return;
        }
        
        if (pos2)
        {
            /* 计算TCP数据包的长度 */
            L206TcpPkgLen = atoi(pos2 + 1);

            /* 如果接收到的TCP数据大于等于设计的最大缓存长度, 忽略数据 */
            if (L206TcpPkgLen >= L206_TCP_RECV_MAX_LEN)
            {
                L206TcpPkgLen = 0;
            }
            else
            {
                memset(L206TcpRecvBuffer, 0, sizeof(L206TcpRecvBuffer));
                L206TcpRecvBufferLen = 0;
            }
        }
    }
    else if (memcmp(cmd, "+CGATT:", 7) == 0)
    {
        uint8_t attached = atoi(cmd + 8);
        
        L206State = attached ? L206_STA_WAKE : L206_STA_ATTACH;
    }
    else if (memcmp(cmd, "CONNECT OK", 10) == 0)
    {
        TcpSetupOkey = true;
    }
    else if (memcmp(cmd, "ALREADY CONNECT", 15) == 0)
    {
        TcpSetupOkey = true;
    }
    else if (memcmp(cmd, "CONNECT FAIL", 12) == 0)
    {
        TcpSetupOkey = false;
    }
    else if (memcmp(cmd, "SEND OK", 7) == 0)
    {
        TcpSendComplete = true;
    }
    else if (memcmp(cmd, "+ICCID", 6) == 0)
    {
        memcpy(L206Iccid, cmd+8, 20);
    }
    else if (memcmp(cmd, "+CPIN: NOT INSERTED", 19) == 0)
    {
        SimCardIsExist = false;
    }
    else if (memcmp(cmd, "CLOSED", 6) == 0) 
    {
        TcpSetupOkey = false;
    }
}

/* 串口空闲中断时调用处理数据, 不可使用断言 */
void L206ProcessUartData(uint8_t *buffer, size_t size)
{
    /* 记录已经接收的AT指令长度 */
    static size_t cmdLen = 0;

    uint8_t *p = NULL;
    size_t i = 0;

    while (i < size)
    {
        p = buffer + i;

        if (L206TcpPkgLen > 0)
        {
            /* 缓存TCP数据 */
            L206TcpRecvBuffer[L206TcpRecvBufferLen++] = *p;
            L206TcpPkgLen--;
            
        }
        else
        {
            /* 处理AT指令 */
            if (*p == '\r')
            {
                *p = '\0';
            }
            else if (*p == '\n')
            {
                *p = '\0';

                if (cmdLen > 0)
                {
                    L206ProcessAtCmd((char *)L206AtRecvBuffer);

                    memset(L206AtRecvBuffer, 0, sizeof(L206AtRecvBuffer));
                    cmdLen = 0;
                }
            }
            else
            {
                /* 接收缓存溢出处理 */
                if (cmdLen >= L206_AT_MAX_LEN)
                {
                    cmdLen = 0;
                }

                if (*p == '>' && cmdLen == 0)
                {
                    /* 如果行首收到字符 '>', 认为udp发送准备就绪 */
                    TcpSendReady = true;
                }
                else
                {
                    /* 缓存AT指令数据 */
                    L206AtRecvBuffer[cmdLen++] = *p;
                }
            }
        }

        i++;
    }
}

