/**
 * @file    ws_client.h
 *
 * @brief   websocket客户端接口
 *
 * @auth    yue_jian
 * @date    2018-3-30 13:13:52
 * @sdk     simplelink_cc2640r2_sdk_01_50_00_58   
 */

#ifndef WS_CLIENT_H
#define WS_CLIENT_H

#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>

/* websocket 操作码 */
typedef enum {
    WS_FRAME_TXT		= 0x01,
    WS_FRAME_BINARY		= 0x02,
    WS_FRAME_CONNECT_CLOSE      = 0x08,
    WS_FRAME_PING		= 0x09,
    WS_FRAME_PONG		= 0x0a,
} ws_opcode_e;

/* websocket帧格式 */
typedef struct {
    char opcode;
    char *payload;
    size_t payloadLen;
} ws_frame_t;

/* websocket握手应答 */
typedef enum {
    WS_RES_101		= 0x00,		// OK
    WS_RES_403		= 0x01,		// Forbidden
    WS_RES_405		= 0x02,		// Method Not Allowed
    WS_RES_426		= 0x03,		// Upgrade Required
    WS_RES_UNKNOWN	= 0x10,		// unknown
} ws_rspcode_e;

/* websocket连接状态 */
typedef enum {
    WS_CLOSED,            //WebSocket连接已经关闭
    WS_CONNECTING,        //正在与服务器建立连接
    WS_HANDSHAKING,       //正在进行WebSocket握手
    WS_CONNECTED,         //已经正常连接
} ws_status_e;

void ws_init(void);

/**@brief 返回当前连接状态
 */
ws_status_e ws_get_status(void);

/**@brief 连接指定服务器 
 */
bool ws_connect(char const *ip, char const *port);

/**@brief 断开当前连接
 */
void ws_close(void);

/**@brief 发送ping包至服务器
 */
void ws_ping(void);

/**@brief 发送握手包至服务器
 */
void ws_send_handshake(char *buf, const char *ip, const char *port, const char *path);

/**@brief 解析握手包应答
 */
ws_rspcode_e ws_process_handshake_response(char *buf, size_t buflen);

/**@brief 发送websocket数据帧
 *
 * @param buf       原始tcp数据缓冲区
 * @param buflen    tcp数据缓冲区最大长度
 * @param 
 */
void ws_send_data_frame(char *buf, size_t buflen, size_t payloadlen, ws_opcode_e code);

/**@brief 解析websocket数据帧
 *
 * @param buf       原始tcp数据
 * @param bulen     原始tpc数据长度
 * @param frame     保存解析结果
 *
 * @retval true     成功
 *         false    非ws格式数据
 */
bool ws_parse_recv_frame(char *buf, size_t buflen, ws_frame_t *frame);

#endif

